function dispAlert(){
    window.alert('アラートの表示');
}

function loadExternalWebsite(){
    window.open('https://watarusuzuki.github.io/apn-profiles/resources/nodata.mobileconfig');
}
