function dispAlert(){
    window.alert('アラートの表示');
}

function loadExternalWebsite(){
    window.open('https://www.googleapis.com/books/v1/volumes?q=harry+potter');
}
